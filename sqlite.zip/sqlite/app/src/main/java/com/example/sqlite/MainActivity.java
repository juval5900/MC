package com.example.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase db;
    Button b1,b,b2;
    EditText e1,e2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button) findViewById(R.id.btn);
        try {
            db=openOrCreateDatabase("StudentDB",SQLiteDatabase.CREATE_IF_NECESSARY,null);
            db.execSQL("Create Table temp(id integer,name text)");
        }
        catch (SQLException e)
        {

        }
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText e1=(EditText) findViewById(R.id.ed1);
                EditText e2=(EditText) findViewById(R.id.ed2);
                ContentValues values=new ContentValues();
                values.put("id",e1.getText().toString());
                values.put("name",e2.getText().toString());
                if((db.insert("temp",null,values))!=-1)
                {
                    Toast.makeText(MainActivity.this, "Record Succesfully inserted", 2000).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "insert error", 2000).show();
                }
                e1.setText("");
                e2.setText("");

            }
        });
        Button b=(Button)findViewById(R.id.b2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c=db.rawQuery("Select * from temp",null);
                c.moveToFirst();
                while(!c.isAfterLast())
                {
                    Toast.makeText(MainActivity.this,c.getString(0)+" "+c.getString(1),1000).show();
                    c.moveToNext();
                }
                c.close();
            }
        });

        Button b3=(Button)findViewById(R.id.b3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText e1=(EditText) findViewById(R.id.ed1);
                EditText e2=(EditText) findViewById(R.id.ed2);
                ContentValues values=new ContentValues();
                String whereClause = "id = ?";
                String[] whereArgs = { e1.getText().toString() };
                values.put("name",e2.getText().toString());
                if((db.update("temp",values,whereClause,whereArgs))!=-1)
                {
                    Toast.makeText(MainActivity.this, "Record Succesfully updated", 2000).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "update error", 2000).show();
                }
                e1.setText("");
                e2.setText("");

            }
        });
        Button btnDel=(Button) findViewById(R.id.b4);
        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();
                values.put("name", e2.getText().toString());
                String whereClause = "id = ?";
                String[] whereArgs = { e1.getText().toString() };

                int rowsDeleted = db.delete("temp", whereClause, whereArgs);

                if (rowsDeleted > 0) {
                    Toast.makeText(MainActivity.this, "Record successfully deleted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Delete Failed", Toast.LENGTH_SHORT).show();
                }

                e1.setText("");
                e2.setText("");
            }
        });
    }
}
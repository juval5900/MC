package com.example.sum;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText ed1,ed2,ed3;
    int a,b,c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1= (Button)findViewById(R.id.btn);
        b2=(Button)findViewById(R.id.btnSub);
        b3=(Button)findViewById(R.id.btnmul);
        b4=(Button)findViewById(R.id.btndiv);
        ed1=(EditText)findViewById(R.id.edf);
        ed2=(EditText)findViewById(R.id.eds);
        ed3=(EditText)findViewById(R.id.edResult);
        b1.setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View view) {
                                      a=Integer.parseInt(ed1.getText().toString());
                                      b=Integer.parseInt(ed2.getText().toString());
                                      c=a+b;
                                      ed3.setText("Result is "+c);
                                      Toast.makeText(getApplicationContext(),"result is"+c,Toast.LENGTH_LONG).show();
                                  }
                              }
        );
        b2.setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View view) {
                                      a=Integer.parseInt(ed1.getText().toString());
                                      b=Integer.parseInt(ed2.getText().toString());
                                      c=a-b;
                                      ed3.setText("Result is "+c);
                                      Toast.makeText(getApplicationContext(),"resultis"+c,Toast.LENGTH_LONG).show();
                                  }
                              }
        );
        b3.setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View view) {
                                      a=Integer.parseInt(ed1.getText().toString());
                                      b=Integer.parseInt(ed2.getText().toString());
                                      c=a*b;
                                      ed3.setText("Result is "+c);
                                      Toast.makeText(getApplicationContext(),"resultis"+c,Toast.LENGTH_LONG).show();
                                  }
                              }
        );
        b4.setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View view) {
                                      a=Integer.parseInt(ed1.getText().toString());
                                      b=Integer.parseInt(ed2.getText().toString());
                                      c=a/b;
                                      ed3.setText("Result is "+c);
                                      Toast.makeText(getApplicationContext(),"resultis"+c,Toast.LENGTH_LONG).show();
                                  }
                              }
        );
    }
}


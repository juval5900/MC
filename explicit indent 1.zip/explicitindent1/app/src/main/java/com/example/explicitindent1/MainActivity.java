package com.example.explicitindent1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button next;
    EditText e1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        next=(Button) findViewById(R.id.button);
        e1=(EditText) findViewById(R.id.ed1);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= e1.getText().toString();
                Intent in=new Intent(MainActivity.this,explicitIndent2.class);
                in.putExtra("key1",1);
                in.putExtra("key2","amal");
                in.putExtra("key3", name);
                startActivity(in);

            }
        });
    }
}
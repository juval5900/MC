package com.example.explicitindent1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class explicitIndent2 extends AppCompatActivity {

    Button home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explicit_indent2);

        home=(Button) findViewById(R.id.button2);
        Intent in= getIntent();

        int a=in.getIntExtra("key1",0);
        String s1= in.getStringExtra("key 2");
        String s2=in.getStringExtra("key3");



        Toast.makeText(getApplicationContext(),"value is"+a,Toast.LENGTH_LONG).show();
        Toast.makeText(getApplicationContext(),s1,Toast.LENGTH_LONG).show();
        Toast.makeText(getApplicationContext(),"name is"+s2,Toast.LENGTH_LONG).show();

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in2=new Intent(explicitIndent2.this,MainActivity.class);
            }
        });



    }
}
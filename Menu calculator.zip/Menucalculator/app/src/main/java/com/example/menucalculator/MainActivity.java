package com.example.menucalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText t1,t2,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1=(EditText) findViewById(R.id.n1);
        t2=(EditText) findViewById(R.id.n2);
        t3=(EditText) findViewById(R.id.n3);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.functions,menu);
            return true;
    }

@Override
    public boolean onOptionsItemSelected(MenuItem item)
{
    int a,b,c;
    a=Integer.parseInt(t1.getText().toString());
    b=Integer.parseInt(t2.getText().toString());
    switch(item.getItemId())
    {
        case R.id.add:
        c=a+b;
        t3.setText(c);
        case R.id.Subtract:
            c=a-b;
            t3.setText(c);
        case R.id.Multiply:
            c=a*b;
            t3.setText(c);
        case R.id.Divide:
            c=a/b;
            t3.setText(c);

        default:
            return false;
    }

}

}
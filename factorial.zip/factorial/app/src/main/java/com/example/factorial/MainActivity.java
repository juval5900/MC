package com.example.factorial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);Button b1 =(Button) findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText Num=(EditText) findViewById(R.id.ed1);
                EditText res=(EditText) findViewById(R.id.ed2);
                int numb=Integer.parseInt(Num.getText().toString());
                int sum =0;
                int temp = numb;
                for (;numb>0;numb /=10){
                    int rem = numb%10;
                    sum += (rem * rem * rem);
                }
                if(sum!=temp){
                    res.setText("Not an Armstrong Number");
                }
                else {
                    res.setText("Is an Armstrong Number");
                }
            }
        });
        Button b2=(Button) findViewById(R.id.b2);

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText Num=(EditText) findViewById(R.id.ed1);
                EditText res=(EditText) findViewById(R.id.ed2);
                int numb=Integer.parseInt(Num.getText().toString());
                if (numb%2==0)
                {
                    res.setText("Even Number");
                }
                else
                {
                    res.setText("Odd Number");
                }

            }
        });
        Button b3=(Button) findViewById(R.id.b3);
        b3.setOnClickListener(view -> {
            EditText Num=(EditText) findViewById(R.id.ed1);
            EditText res=(EditText) findViewById(R.id.ed2);
            int numb=Integer.parseInt(Num.getText().toString());
            int sum =1;
            for (;numb>0;numb--){
                sum *= numb;
            }
            res.setText(""+sum);
        });
    }
}


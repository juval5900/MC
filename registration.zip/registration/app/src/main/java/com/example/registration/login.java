package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class login extends AppCompatActivity {
    Button btn;
    TextView txt1,txt2,txt3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Intent i=getIntent();
        btn = (Button) findViewById(R.id.btn2);
        txt1=(TextView)findViewById(R.id.output);
        txt2=(TextView)findViewById(R.id.output2);
        txt3=(TextView)findViewById(R.id.output3);

        String name = i.getStringExtra("Name");
        String ph = i.getStringExtra("Phone");
        String gender = i.getStringExtra("Gender");

        txt1.setText(name);
        txt2.setText(ph);
        txt3.setText(gender);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent (login.this, MainActivity.class);
                Intent intent = getIntent();
                startActivity(i);
            }
        });
    }
}
